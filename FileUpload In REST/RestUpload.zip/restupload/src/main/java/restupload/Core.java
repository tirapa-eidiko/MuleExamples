package restupload;

import org.mule.el.context.MessageContext;

import org.mule.message.ds.ByteArrayDataSource;

import javax.activation.DataHandler;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.ByteArrayOutputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
public class Core {

	public Object getUpdatedPayload(MessageContext messageContext) throws Exception {

FileInputStream fis = null;
		
		try {
		
		File file = new File("C:/shekhar/pdf.pdf");
			fis = new FileInputStream(file);
			
			ByteArrayOutputStream bs = new ByteArrayOutputStream();

			int c;
			while ((c = fis.read()) != -1) {
				bs.write(c);
			}
			fis.close();

			ByteArrayDataSource pdf = new ByteArrayDataSource(bs.toByteArray(), "application/pdf",
					"new2");

			DataHandler data = new DataHandler(pdf);

			messageContext.getOutboundAttachments().put("file", data);
		} catch (IOException e) {

			fis.close();

		}

		return messageContext.getPayload();
	}

}



